# Experiment 3 – HTML Basics

## Learning Outcomes
After completing this experiment, I am able to:
- Understand the basic structure of an HTML document
- Use common HTML tags such as headings, paragraphs, lists, and links
- Create a simple static web page using HTML
- Improve understanding of front-end web development fundamentals